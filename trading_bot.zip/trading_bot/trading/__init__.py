"""
Trading package for strategy, execution, and position management.
"""