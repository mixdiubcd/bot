"""
Models package for trading state and instrument definitions.
"""