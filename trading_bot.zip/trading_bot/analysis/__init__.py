"""
Analysis package for technical indicators and signal generation.
"""