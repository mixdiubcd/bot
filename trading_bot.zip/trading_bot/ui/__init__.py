"""
UI package for dashboard, callbacks, and components.
"""