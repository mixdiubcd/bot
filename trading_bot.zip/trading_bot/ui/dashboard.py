"""
Main dashboard layout for the options trading dashboard.
"""

import dash
from dash import dcc, html
import dash_bootstrap_components as dbc

from config import Config

# Initialize Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

def create_dashboard():
    """Create the main dashboard layout."""
    config = Config()
    
    layout = dbc.Container(
        [
            dbc.Row([
                dbc.Col([
                    html.H1("Multi-Index Options Trading Dashboard", className="text-center mb-4")
                ])
            ]),
            
            dcc.Tabs([
                # NIFTY Tab
                dcc.Tab(label="NIFTY", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY")),
                                dbc.CardBody([
                                    html.H2(id="nifty-price"),
                                    html.P(id="nifty-movement"),
                                    html.P(id="nifty-trend"),
                                    html.P(["Volatility: ", html.Span(id="nifty-volatility")]),
                                    html.P(["Predicted Range: ", html.Span(id="nifty-range")]),
                                    html.P(["PCR: ", html.Span(id="nifty-pcr")]),
                                    html.P(["Expiry: ", html.Span(id="nifty-expiry")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY Performance")),
                                dbc.CardBody([
                                    html.H5("P&L"),
                                    html.P(["NIFTY P&L: ", html.Span(id="nifty-pnl")]),
                                    html.P(["NIFTY Trades: ", html.Span(id="nifty-trades")]),
                                    html.P(["WebSocket: ", html.Span(id="websocket-status-nifty", className="text-muted")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY CE Option")),
                                dbc.CardBody([
                                    html.H5(id="nifty-ce-symbol"),
                                    html.P(id="nifty-ce-price"),
                                    html.P(id="nifty-ce-signal"),
                                    html.P(["Signal Value: ", html.Span(id="nifty-ce-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="nifty-ce-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY PE Option")),
                                dbc.CardBody([
                                    html.H5(id="nifty-pe-symbol"),
                                    html.P(id="nifty-pe-price"),
                                    html.P(id="nifty-pe-signal"),
                                    html.P(["Signal Value: ", html.Span(id="nifty-pe-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="nifty-pe-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY Active Trades")),
                                dbc.CardBody(id="nifty-active-trades-container")
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("NIFTY Recent Trades")),
                                dbc.CardBody(id="nifty-recent-trades-container")
                            ], className="mb-4")
                        ], width=6)
                    ]),
                ]),
                
                # BANKNIFTY Tab
                dcc.Tab(label="BANKNIFTY", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY")),
                                dbc.CardBody([
                                    html.H2(id="banknifty-price"),
                                    html.P(id="banknifty-movement"),
                                    html.P(id="banknifty-trend"),
                                    html.P(["Volatility: ", html.Span(id="banknifty-volatility")]),
                                    html.P(["Predicted Range: ", html.Span(id="banknifty-range")]),
                                    html.P(["PCR: ", html.Span(id="banknifty-pcr")]),
                                    html.P(["Expiry: ", html.Span(id="banknifty-expiry")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY Performance")),
                                dbc.CardBody([
                                    html.H5("P&L"),
                                    html.P(["BANKNIFTY P&L: ", html.Span(id="banknifty-pnl")]),
                                    html.P(["BANKNIFTY Trades: ", html.Span(id="banknifty-trades")]),
                                    html.P(["WebSocket: ", html.Span(id="websocket-status-banknifty", className="text-muted")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY CE Option")),
                                dbc.CardBody([
                                    html.H5(id="banknifty-ce-symbol"),
                                    html.P(id="banknifty-ce-price"),
                                    html.P(id="banknifty-ce-signal"),
                                    html.P(["Signal Value: ", html.Span(id="banknifty-ce-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="banknifty-ce-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY PE Option")),
                                dbc.CardBody([
                                    html.H5(id="banknifty-pe-symbol"),
                                    html.P(id="banknifty-pe-price"),
                                    html.P(id="banknifty-pe-signal"),
                                    html.P(["Signal Value: ", html.Span(id="banknifty-pe-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="banknifty-pe-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY Active Trades")),
                                dbc.CardBody(id="banknifty-active-trades-container")
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("BANKNIFTY Recent Trades")),
                                dbc.CardBody(id="banknifty-recent-trades-container")
                            ], className="mb-4")
                        ], width=6)
                    ]),
                ]),
                
                # SENSEX Tab
                dcc.Tab(label="SENSEX", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX")),
                                dbc.CardBody([
                                    html.H2(id="sensex-price"),
                                    html.P(id="sensex-movement"),
                                    html.P(id="sensex-trend"),
                                    html.P(["Volatility: ", html.Span(id="sensex-volatility")]),
                                    html.P(["Predicted Range: ", html.Span(id="sensex-range")]),
                                    html.P(["PCR: ", html.Span(id="sensex-pcr")]),
                                    html.P(["Expiry: ", html.Span(id="sensex-expiry")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX Performance")),
                                dbc.CardBody([
                                    html.H5("P&L"),
                                    html.P(["SENSEX P&L: ", html.Span(id="sensex-pnl")]),
                                    html.P(["SENSEX Trades: ", html.Span(id="sensex-trades")]),
                                    html.P(["WebSocket: ", html.Span(id="websocket-status-sensex", className="text-muted")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX CE Option")),
                                dbc.CardBody([
                                    html.H5(id="sensex-ce-symbol"),
                                    html.P(id="sensex-ce-price"),
                                    html.P(id="sensex-ce-signal"),
                                    html.P(["Signal Value: ", html.Span(id="sensex-ce-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="sensex-ce-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX PE Option")),
                                dbc.CardBody([
                                    html.H5(id="sensex-pe-symbol"),
                                    html.P(id="sensex-pe-price"),
                                    html.P(id="sensex-pe-signal"),
                                    html.P(["Signal Value: ", html.Span(id="sensex-pe-signal-value")]),
                                    html.P(["Strength Value: ", html.Span(id="sensex-pe-strength-value")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX Active Trades")),
                                dbc.CardBody(id="sensex-active-trades-container")
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("SENSEX Recent Trades")),
                                dbc.CardBody(id="sensex-recent-trades-container")
                            ], className="mb-4")
                        ], width=6)
                    ]),
                ]),
                
                # Overall Performance Tab
                dcc.Tab(label="Overall Performance", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Overall Performance")),
                                dbc.CardBody([
                                    html.H5("P&L"),
                                    html.P(["Total: ", html.Span(id="total-pnl")]),
                                    html.P(["Today: ", html.Span(id="daily-pnl")]),
                                    html.P(["Win Rate: ", html.Span(id="win-rate")]),
                                    html.P(["Trades Today: ", html.Span(id="trades-today", className="text-muted")]),
                                    html.P(["WebSocket: ", html.Span(id="websocket-status", className="text-muted")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Index Performance Comparison")),
                                dbc.CardBody([
                                    html.P(["NIFTY P&L: ", html.Span(id="overall-nifty-pnl")]),
                                    html.P(["BANKNIFTY P&L: ", html.Span(id="overall-banknifty-pnl")]),
                                    html.P(["SENSEX P&L: ", html.Span(id="overall-sensex-pnl")]),
                                    html.P(["Best Performing Index: ", html.Span(id="best-index")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Trade Statistics")),
                                dbc.CardBody([
                                    html.P(["Total Trades: ", html.Span(id="total-trades")]),
                                    html.P(["NIFTY Trades: ", html.Span(id="overall-nifty-trades")]),
                                    html.P(["BANKNIFTY Trades: ", html.Span(id="overall-banknifty-trades")]),
                                    html.P(["SENSEX Trades: ", html.Span(id="overall-sensex-trades")]),
                                    html.P(["Regular Trades: ", html.Span(id="regular-trades")]),
                                    html.P(["Regular Trades P&L: ", html.Span(id="regular-trades-pnl")]),
                                    html.P(["Regular Win Rate: ", html.Span(id="regular-win-rate")])
                                ])
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Scalping Performance")),
                                dbc.CardBody([
                                    html.P(["Scalping Mode: ", html.Span(id="scalping-mode")]),
                                    html.P(["Scalping P&L: ", html.Span(id="scalping-pnl")]),
                                    html.P(["Scalping Win Rate: ", html.Span(id="scalping-win-rate")]),
                                    html.P(["Avg. Scalping Trade Duration: ", html.Span(id="scalping-avg-duration")]),
                                    html.P(["Best Scalping Day: ", html.Span(id="best-scalping-day")]),
                                    html.P(["Best Expiry Performance: ", html.Span(id="best-expiry-performance")])
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Recent Trades Across All Indices")),
                                dbc.CardBody(id="all-recent-trades-container")
                            ], className="mb-4")
                        ], width=12)
                    ])
                ]),
                
                # Scalping Analytics Tab
                dcc.Tab(label="Scalping Analytics", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Daily Scalping Performance")),
                                dbc.CardBody(id="daily-scalping-performance")
                            ], className="mb-4")
                        ], width=12)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Expiry Day Performance")),
                                dbc.CardBody(id="expiry-day-performance")
                            ], className="mb-4")
                        ], width=6),
                        
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Scalping Strategy Settings")),
                                dbc.CardBody([
                                    html.P("Target Percentage:"),
                                    dcc.Slider(
                                        id='scalping-target-slider',
                                        min=0.1,
                                        max=1.0,
                                        step=0.1,
                                        value=config.scalping_target_pct,
                                        marks={i/10: f'{i/10:.1f}%' for i in range(1, 11)},
                                    ),
                                    html.P("Stop Loss Percentage:"),
                                    dcc.Slider(
                                        id='scalping-sl-slider',
                                        min=0.1,
                                        max=1.0,
                                        step=0.1,
                                        value=config.scalping_stop_loss_pct,
                                        marks={i/10: f'{i/10:.1f}%' for i in range(1, 11)},
                                    ),
                                    html.P("Maximum Holding Time (minutes):"),
                                    dcc.Slider(
                                        id='scalping-max-time-slider',
                                        min=1,
                                        max=10,
                                        step=1,
                                        value=5,  # Default value
                                        marks={i: f'{i}' for i in range(1, 11)},
                                    ),
                                    html.Div([
                                        dbc.Button("Update Settings", id="update-scalping-settings", color="primary", className="mt-3")
                                    ]),
                                    html.Div(id="scalping-settings-status", className="mt-2")
                                ])
                            ], className="mb-4")
                        ], width=6)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Scalping Trade Analysis")),
                                dbc.CardBody(id="scalping-trade-analysis")
                            ], className="mb-4")
                        ], width=12)
                    ])
                ]),
                
                # Option Configuration Tab
                dcc.Tab(label="Option Configuration", children=[
                    dbc.Row([
                        dbc.Col([
                            dbc.Card([
                                dbc.CardHeader(html.H4("Option Configuration")),
                                dbc.CardBody([
                                    html.P("Automatically fetch and update ATM options for all indices"),
                                    dbc.Button("Refresh ATM Options", id="refresh-atm-button", color="primary", className="mr-2"),
                                    html.Div(id="atm-refresh-status", className="mt-2"),
                                    html.Div([
                                        html.H5("Current ATM Options", className="mt-3"),
                                        html.Div(id="current-atm-options")
                                    ], className="mt-3")
                                ])
                            ], className="mb-4")
                        ], width=12)
                    ])
                ])
            ]),
            
            dcc.Interval(
                id='interval-component',
                interval=1000,  # in milliseconds
                n_intervals=0
            ),
            
            dcc.Interval(
                id='option-display-interval',
                interval=5000,  # in milliseconds
                n_intervals=0
            )
        ],
        fluid=True,
        className="p-4"
    )
    
    return layout

def initialize_dashboard():
    """Initialize the dashboard with the layout."""
    app.layout = create_dashboard()
    return app